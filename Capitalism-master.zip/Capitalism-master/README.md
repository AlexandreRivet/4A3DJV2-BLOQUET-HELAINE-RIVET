Capitalism
==========

Python card game
